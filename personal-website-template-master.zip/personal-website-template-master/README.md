# personal-website-template

A simple one page template suited for personal and portfolio pages. 

## Usage

- Fork this repository
- Rename it to `<your-github-username>.github.io`
- Edit `index.html` to add your personal details
- Goto `http://<your-github-username.github.io` and website will be visible there
